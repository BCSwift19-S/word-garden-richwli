import UIKit

var str = "Hello, playground"
var empty = ""
for i in 0..<str.count{
    empty+="_ "
}
func findAndInsert(char: Character, s: String) -> String?{
    empty = ""
    for c in s{
        if(c==char){
            empty+="\(char) "
        }else{
            empty += "_ "
        }
    }
    return empty
}

findAndInsert(char: "l",s: str)
